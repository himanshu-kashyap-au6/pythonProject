from setuptools import setup

setup(name='mazesolverhk',
version='0.1',
description='This is maze-solver code with the shortest path',
author='Himanshu Kashyap',
packages=['mazesolverhk'],
install_requires=[])